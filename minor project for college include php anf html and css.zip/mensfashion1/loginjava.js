document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    // Add your login functionality here
    alert("Logged in successfully!");
  });