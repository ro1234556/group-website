<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the latest order for display purposes
$sql = "SELECT user_name, payment_mode, total_amount, order_details 
        FROM orders ORDER BY id DESC LIMIT 1";

$result = $conn->query($sql);
$order = $result->fetch_assoc();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Order Confirmation</h1>
        <p>Thank you for your purchase, <strong><?php echo htmlspecialchars($order['user_name']); ?></strong>!</p>
        <p>Your payment method: <strong><?php echo htmlspecialchars($order['payment_mode']); ?></strong></p>
        <p>Total Amount: INR <strong><?php echo number_format($order['total_amount'], 2); ?></strong></p>

        <h3>Order Details</h3>
        <ul>
            <?php
            $orderItems = json_decode($order['order_details'], true);
            foreach ($orderItems as $item) {
                echo "<li>{$item['name']} (x{$item['quantity']}): INR " . number_format($item['price'] * $item['quantity'], 2) . "</li>";
            }
            ?>
        </ul>
        <a href="men Fashion.html" class="btn btn-primary mt-3">Back to Home</a>
    </div>
</body>
</html>
