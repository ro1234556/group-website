<?php
// process_payment.php

// Database connection
$servername = "localhost";
$username = "root"; // replace with your MySQL username
$password = ""; // replace with your MySQL password
$dbname = "userorder"; // database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the orders table is empty and reset auto-increment if so
$checkEmptyTable = "SELECT COUNT(*) as count FROM orders";
$result = $conn->query($checkEmptyTable);
$row = $result->fetch_assoc();

if ($row['count'] == 0) {
    $resetAutoIncrement = "ALTER TABLE orders AUTO_INCREMENT = 1";
    $conn->query($resetAutoIncrement);
}

// Read the JSON data sent from the front-end
$data = json_decode(file_get_contents("php://input"), true);

// Validate the received data
if (isset($data['userName']) && isset($data['userAddress']) && isset($data['paymentMode']) && isset($data['totalAmount']) && isset($data['cart'])) {
    $userName = $conn->real_escape_string($data['userName']);
    $userAddress = $conn->real_escape_string($data['userAddress']);
    $paymentMode = $conn->real_escape_string($data['paymentMode']);
    $totalAmount = $data['totalAmount'];

    // Prepare the SQL query to insert the order data
    $sql = "INSERT INTO orders (user_name, user_address, payment_mode, total_amount) 
            VALUES ('$userName', '$userAddress', '$paymentMode', '$totalAmount')";

    if ($conn->query($sql) === TRUE) {
        // Successfully inserted data into the database
        $response = [
            "success" => true,
            "message" => "Your order has been placed successfully, $userName!"
        ];
    } else {
        // Error inserting data into the database
        $response = [
            "success" => false,
            "error" => "Error processing payment: " . $conn->error
        ];
    }
} else {
    // Missing required data
    $response = [
        "success" => false,
        "error" => "Missing required fields."
    ];
}

// Close the database connection
$conn->close();

// Send response back to the client
header('Content-Type: application/json');
echo json_encode($response);
?>
