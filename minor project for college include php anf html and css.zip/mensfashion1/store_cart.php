<?php
// Set the header for JSON responses
header('Content-Type: application/json');

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";  // Your MySQL password
$dbname = "mensfashion";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    echo json_encode(['error' => 'Database connection failed: ' . $conn->connect_error]);
    exit;
}

// Check if the request method is POST and if the action is 'checkout'
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the raw POST data (since the data is now JSON)
    $inputData = json_decode(file_get_contents('php://input'), true);

    // Check if the data is decoded properly
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['error' => 'Invalid JSON data received']);
        exit;
    }

    // Get the cart data from the decoded JSON
    $cart = isset($inputData['cart']) ? $inputData['cart'] : [];
    $action = isset($inputData['action']) ? $inputData['action'] : '';

    // If action is 'checkout' and cart is not empty
    if ($action == 'checkout' && !empty($cart)) {
        $receiptDate = date('Y-m-d H:i:s');
        $grandTotal = 0;
        $newIds = [];

        // Loop through each item in the cart and insert it into the database
        foreach ($cart as $item) {
            $name = $conn->real_escape_string($item['name']);
            $quantity = intval($item['quantity']);
            $price = floatval($item['price']);
            $total = $quantity * $price;
            $grandTotal += $total;

            // Prepare SQL query to insert data into the cart_receipts table
            $sql = "INSERT INTO cart_receipts (item_name, quantity, price, total, date) 
                    VALUES ('$name', $quantity, $price, $total, '$receiptDate')";

            // Execute the query
            if ($conn->query($sql)) {
                // Get the ID of the last inserted row
                $newId = $conn->insert_id;
                $newIds[] = $newId;  // Store the new ID for each item inserted
            } else {
                echo json_encode(['error' => 'Error saving cart data: ' . $conn->error]);
                exit;
            }
        }

        // Close the database connection
        $conn->close();

        // Return a success response with the grand total, receipt date, and new IDs
        echo json_encode([
            'success' => true,
            'date' => $receiptDate,
            'grandTotal' => $grandTotal,
            'newIds' => $newIds,  // Return the array of new IDs
            'message' => 'Cart data saved successfully'
        ]);
    } else {
        // Handle error if no cart data or invalid action
        echo json_encode(['error' => 'No cart data or invalid action']);
    }
} else {
    // Handle error if not a POST request
    echo json_encode(['error' => 'Invalid request method']);
}
?>
