<?php
// database.php
$servername = "localhost";
$username = "root";
$password = "";  // Enter your database password
$dbname = "users";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
